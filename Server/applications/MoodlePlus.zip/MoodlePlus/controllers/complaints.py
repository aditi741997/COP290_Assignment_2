def index():
	return dict(sucess=True)

def new():
	return dict(success=True)