# coding: utf-8
{
# "singular form (0)": ["first plural form (1)", "second plural form (2)", ...],
'fila': ['filas'],
'eliminada': ['eliminadas'],
'actualizada': ['actualizadas'],
'seleccionado': ['seleccionados'],
}
